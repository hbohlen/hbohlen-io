# 12. Security
The security posture relies on declarative management of user privileges, SSH public-key authentication for servers, full-disk encryption (LUKS) for physical machines, and encrypted secret management via `sops-nix`.

---