#!/bin/bash
# ZFS Migration Script for NixOS
# Run this from NixOS installation media after cloning your repo

set -e

# Check if we're in the correct directory
if [ ! -f "flake.nix" ] || [ ! -d "hosts" ]; then
    echo "Error: This script must be run from the nixos directory of your cloned repository"
    echo "Expected path: /tmp/hbohlen-io/nixos/"
    exit 1
fi

echo "=== ZFS Migration Script ==="
echo "WARNING: This will destroy existing data on target disk!"
read -p "Continue? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    exit 1
fi

# Configuration - adjust these values
TARGET_DISK="/dev/nvme1n1"  # Change to your target disk (e.g., /dev/nvme1n1)
POOL_NAME="rpool"
BACKUP_MOUNT="/mnt/backup"
HOSTNAME="desktop"     # Change to desktop, laptop, or server

echo "Step 1: Checking for existing system backup..."
mkdir -p $BACKUP_MOUNT
mount /dev/disk/by-label/nixos $BACKUP_MOUNT 2>/dev/null || echo "Note: No existing system found for backup (fresh install)"

echo "Step 2: Partitioning disk for ZFS..."
# Clear existing partition table
wipefs -a $TARGET_DISK

# Create GPT partition table
parted $TARGET_DISK mklabel gpt

# Create EFI partition (512MB)
parted $TARGET_DISK mkpart ESP fat32 1MiB 513MiB
parted $TARGET_DISK set 1 esp on

# Create ZFS partition (remaining space)
parted $TARGET_DISK mkpart zfs 513MiB 100%

echo "Step 3: Creating ZFS pool..."
zpool create -f -o ashift=12 \
    -O compression=lz4 \
    -O atime=off \
    -O xattr=sa \
    -O acltype=posixacl \
    -O mountpoint=legacy \
    $POOL_NAME $TARGET_DISK"2"

echo "Step 4: Creating ZFS datasets..."
# Root dataset
zfs create -o mountpoint=legacy $POOL_NAME/root

# Nix store dataset
zfs create -o mountpoint=legacy $POOL_NAME/nix

# Home dataset
zfs create -o mountpoint=legacy $POOL_NAME/home

# Persist dataset for impermanence
zfs create -o mountpoint=legacy $POOL_NAME/persist

# System datasets
zfs create -o mountpoint=legacy $POOL_NAME/persist/system
zfs create -o mountpoint=legacy $POOL_NAME/persist/home

echo "Step 5: Creating filesystem structure..."
mkdir -p /mnt
mount -t zfs $POOL_NAME/root /mnt
mkdir -p /mnt/{boot,nix,home,persist}

# Mount EFI partition
mkfs.fat -F 32 $TARGET_DISK"1"
mount $TARGET_DISK"1" /mnt/boot

# Mount other datasets
mount -t zfs $POOL_NAME/nix /mnt/nix
mount -t zfs $POOL_NAME/home /mnt/home
mount -t zfs $POOL_NAME/persist /mnt/persist

echo "Step 6: Copying your NixOS configuration..."
# Copy your custom configuration to the target system
cp -r /tmp/hbohlen-io/nixos/* /mnt/etc/nixos/
cd /mnt/etc/nixos

echo "Step 7: Installing NixOS with ZFS support..."
# Install using your custom configuration
nixos-install --root /mnt --flake .#$HOSTNAME

echo "Step 9: Installing GRUB bootloader..."
# This will be handled by nixos-install, but we can verify
echo "GRUB installation completed by nixos-install"

echo "Step 10: Final cleanup..."
zpool set bootfs=$POOL_NAME/root $POOL_NAME
zpool export $POOL_NAME
zpool import -R /mnt $POOL_NAME

echo "=== Migration Complete ==="
echo "Next steps:"
echo "1. Reboot into the new ZFS system"
echo "2. Verify all services are working"
echo "3. Test ZFS snapshots: zfs snapshot $POOL_NAME/root@initial"
echo "4. Test rollback: zfs rollback $POOL_NAME/root@initial"

echo "=== ZFS Pool Status ==="
zpool status