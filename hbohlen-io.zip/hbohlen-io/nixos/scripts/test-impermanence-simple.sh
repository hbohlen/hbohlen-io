#!/usr/bin/env bash

echo "=== Testing Impermanence Setup ==="

# Build the test configuration
echo "Building test configuration..."
nix --extra-experimental-features 'nix-command flakes' build '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.system.build.toplevel'

if [ $? -eq 0 ]; then
    echo "✓ Configuration builds successfully"
else
    echo "✗ Configuration failed to build"
    exit 1
fi

# Check if the VM builds
echo "Building VM..."
nix --extra-experimental-features 'nix-command flakes' build '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.system.build.vm'

if [ $? -eq 0 ]; then
    echo "✓ VM builds successfully"
else
    echo "✗ VM failed to build"
    exit 1
fi

# Check the generated configuration
echo "Checking generated configuration..."
CONFIG_PATH=$(nix --extra-experimental-features 'nix-command flakes' eval --raw '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.system.build.toplevel')

echo "Configuration path: $CONFIG_PATH"

# Check if impermanence module is enabled
echo "Checking impermanence module..."
if nix --extra-experimental-features 'nix-command flakes' eval '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.environment.persistence' 2>/dev/null; then
    echo "✓ Impermanence persistence is configured"
else
    echo "✗ Impermanence persistence not found"
fi

# Check if root filesystem is tmpfs
echo "Checking root filesystem..."
ROOT_FS=$(nix --extra-experimental-features 'nix-command flakes' eval --json '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.fileSystems."/".fsType' 2>/dev/null)
if [[ "$ROOT_FS" == *"tmpfs"* ]]; then
    echo "✓ Root filesystem is tmpfs"
else
    echo "✗ Root filesystem is not tmpfs: $ROOT_FS"
fi

# Check if persistent filesystem exists
echo "Checking persistent filesystem..."
PERSIST_FS=$(nix --extra-experimental-features 'nix-command flakes' eval --json '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.fileSystems."/persist"' 2>/dev/null)
if [[ "$PERSIST_FS" != "" ]]; then
    echo "✓ Persistent filesystem is configured"
else
    echo "✗ Persistent filesystem not found"
fi

echo ""
echo "=== Summary ==="
echo "The impermanence setup has been configured with:"
echo "- Root filesystem as tmpfs (ephemeral)"
echo "- Persistent filesystem at /persist"
echo "- Test VM can be built successfully"
echo ""
echo "To test impermanence behavior:"
echo "1. Run the VM: ./result/bin/run-desktop-test-vm -nographic"
echo "2. Login with hbohlen/test123"
echo "3. Create test files and reboot to verify persistence behavior"