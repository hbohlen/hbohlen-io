#!/usr/bin/env bash

echo "=== Testing BTRFS Impermanence Setup ==="

# Build the test configuration
echo "Building test configuration..."
nix --extra-experimental-features 'nix-command flakes' build '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.system.build.toplevel'

if [ $? -eq 0 ]; then
    echo "✓ Configuration builds successfully"
else
    echo "✗ Configuration failed to build"
    exit 1
fi

# Check if the VM builds
echo "Building VM..."
nix --extra-experimental-features 'nix-command flakes' build '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.system.build.vm'

if [ $? -eq 0 ]; then
    echo "✓ VM builds successfully"
else
    echo "✗ VM failed to build"
    exit 1
fi

# Check BTRFS configuration
echo "Checking BTRFS filesystem..."
ROOT_FS=$(nix --extra-experimental-features 'nix-command flakes' eval --json '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.fileSystems."/".fsType' 2>/dev/null)
if [[ "$ROOT_FS" == *"tmpfs"* ]]; then
    echo "✓ Root filesystem is tmpfs (ephemeral)"
else
    echo "✗ Root filesystem is not tmpfs: $ROOT_FS"
fi

PERSIST_FS=$(nix --extra-experimental-features 'nix-command flakes' eval --json '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.fileSystems."/persist".fsType' 2>/dev/null)
if [[ "$PERSIST_FS" == *"btrfs"* ]]; then
    echo "✓ Persistent filesystem is BTRFS"
else
    echo "✗ Persistent filesystem is not BTRFS: $PERSIST_FS"
fi

# Check BTRFS mount options
echo "Checking BTRFS mount options..."
MOUNT_OPTS=$(nix --extra-experimental-features 'nix-command flakes' eval --json '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.fileSystems."/persist".options' 2>/dev/null)
if [[ "$MOUNT_OPTS" == *"compress=zstd"* ]]; then
    echo "✓ BTRFS compression enabled (zstd)"
else
    echo "✗ BTRFS compression not enabled"
fi

if [[ "$MOUNT_OPTS" == *"noatime"* ]]; then
    echo "✓ BTRFS noatime enabled"
else
    echo "✗ BTRFS noatime not enabled"
fi

# Check BTRFS services
echo "Checking BTRFS services..."
BTRFS_SCRUB_SERVICE=$(nix --extra-experimental-features 'nix-command flakes' eval '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.systemd.services."btrfs-scrub".enable' 2>/dev/null)
if [[ "$BTRFS_SCRUB_SERVICE" != "" ]]; then
    echo "✓ BTRFS scrub service enabled"
else
    echo "✗ BTRFS scrub service not enabled"
fi

BTRFS_SCRUB_TIMER=$(nix --extra-experimental-features 'nix-command flakes' eval '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.systemd.timers."btrfs-scrub".enable' 2>/dev/null)
if [[ "$BTRFS_SCRUB_TIMER" != "" ]]; then
    echo "✓ BTRFS scrub timer enabled"
else
    echo "✗ BTRFS scrub timer not enabled"
fi

# Check BTRFS tools
echo "Checking BTRFS tools..."
BTRFS_TOOLS=$(nix --extra-experimental-features 'nix-command flakes' eval --json '/home/hbohlen/hbohlen-io/nixos#nixosConfigurations."desktop-test".config.environment.systemPackages' 2>/dev/null)
if [[ "$BTRFS_TOOLS" == *"btrfs-progs"* ]]; then
    echo "✓ BTRFS tools installed"
else
    echo "✗ BTRFS tools not installed"
fi

if [[ "$BTRFS_TOOLS" == *"compsize"* ]]; then
    echo "✓ BTRFS compsize tool installed"
else
    echo "✗ BTRFS compsize tool not installed"
fi

if [[ "$BTRFS_TOOLS" == *"snapper"* ]]; then
    echo "✓ Snapper snapshot tool installed"
else
    echo "✗ Snapper snapshot tool not installed"
fi

echo ""
echo "=== BTRFS Subvolume Structure ==="
echo "The BTRFS setup includes the following subvolumes:"
echo "- @ (root) -> mounted at /persist"
echo "- system -> mounted at /persist/system"
echo "- home -> mounted at /persist/home"
echo "- nix -> mounted at /persist/nix"
echo "- snapshots -> for BTRFS snapshots (not mounted by default)"

echo ""
echo "=== BTRFS Benefits Enabled ==="
echo "✓ Compression: zstd for space savings"
echo "✓ Noatime: reduced disk writes"
echo "✓ Auto-scrub: monthly data integrity checks"
echo "✓ Subvolumes: organized persistent storage"
echo "✓ Snapshot support: via snapper tool"

echo ""
echo "=== Testing Commands for VM ==="
echo "Once in the VM, you can test BTRFS features:"
echo ""
echo "1. Check BTRFS filesystem:"
echo "   sudo btrfs filesystem show /persist"
echo ""
echo "2. List subvolumes:"
echo "   sudo btrfs subvolume list /persist"
echo ""
echo "3. Check compression stats:"
echo "   sudo compsize /persist"
echo ""
echo "4. Create manual snapshot:"
echo "   sudo btrfs subvolume snapshot /persist/system /persist/snapshots/system-\$(date +%Y%m%d)"
echo ""
echo "5. Test impermanence:"
echo "   echo 'ephemeral' > /tmp/test.txt"
echo "   echo 'persistent' > /persist/test.txt"
echo "   reboot"
echo "   # After reboot, /tmp/test.txt should be gone, /persist/test.txt should remain"

echo ""
echo "=== To Run VM ==="
echo "./result/bin/run-desktop-test-vm -nographic"
echo "Login: hbohlen / test123"