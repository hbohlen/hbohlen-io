#!/usr/bin/env bash

set -euo pipefail

# Script to test impermanence configuration with QEMU

echo "=== Setting up QEMU test environment for impermanence ==="

# Create virtual disk for testing
DISK_IMAGE="./test-impermanence.qcow2"
DISK_SIZE="20G"

echo "Creating virtual disk image: $DISK_IMAGE ($DISK_SIZE)"
if [ ! -f "$DISK_IMAGE" ]; then
    qemu-img create -f qcow2 "$DISK_IMAGE" "$DISK_SIZE"
    echo "Virtual disk created successfully"
else
    echo "Virtual disk already exists"
fi

# Build the NixOS VM configuration
echo "Building NixOS VM with impermanence test configuration..."
nixos-rebuild build-vm --flake .#desktop-test

if [ $? -eq 0 ]; then
    echo "VM build successful"
    echo ""
    echo "To run the VM with the virtual disk:"
    echo "  ./result/bin/run-nixos-vm -drive file=$DISK_IMAGE,format=qcow2,index=0,media=disk"
    echo ""
    echo "To run with more memory and CPU cores:"
    echo "  ./result/bin/run-nixos-vm -m 8G -smp 4 -drive file=$DISK_IMAGE,format=qcow2,index=0,media=disk"
    echo ""
    echo "To run with GUI support:"
    echo "  ./result/bin/run-nixos-vm -m 8G -smp 4 -drive file=$DISK_IMAGE,format=qcow2,index=0,media=disk -vga virtio -display gtk,gl=on"
    echo ""
    echo "Test credentials:"
    echo "  Username: hbohlen"
    echo "  Password: test123"
    echo ""
    echo "Note: The VM will use a test configuration with impermanence."
    echo "The root filesystem will be tmpfs (ephemeral) and /persist will be on the virtual disk."
    echo ""
    echo "To test impermanence:"
    echo "  1. Create a file in /home/hbohlen/test.txt"
    echo "  2. Reboot the VM"
    echo "  3. Check if the file is gone (it should be)"
    echo "  4. Create a file in /persist/test.txt"
    echo "  5. Reboot the VM"
    echo "  6. Check if the file persists (it should)"
else
    echo "VM build failed!"
    exit 1
fi