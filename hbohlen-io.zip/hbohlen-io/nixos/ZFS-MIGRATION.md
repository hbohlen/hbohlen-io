# ZFS Migration Guide

This guide explains how to migrate your NixOS setup from BTRFS to ZFS.

## Why ZFS?

- **Data Integrity**: ZFS provides end-to-end checksums to detect and prevent silent data corruption
- **Snapshots**: Instant, space-efficient snapshots for system rollback
- **Compression**: Built-in compression (lz4) saves disk space
- **Reliability**: More robust than BTRFS for production use
- **Performance**: Better caching and memory management

## Migration Steps

### 1. Backup Current System

Before migrating, create a complete backup:

```bash
# Create BTRFS snapshot
sudo btrfs subvolume snapshot / /snapshot-before-zfs-migration

# Create full backup to external drive
sudo rsync -aAXv / /mnt/external-backup/ \
  --exclude=/mnt/external-backup \
  --exclude=/proc \
  --exclude=/sys \
  --exclude=/dev \
  --exclude=/tmp \
  --exclude=/run
```

### 2. Prepare Installation Media

Download the latest NixOS minimal ISO and boot from it.

### 3. Run Migration Script

Once booted into the installation media:

```bash
# Clone your configuration
git clone https://github.com/yourusername/hbohlen-io.git
cd hbohlen-io

# Run the migration script
sudo ./nixos/scripts/migrate-to-zfs.sh
```

### 4. Update Host Configurations

After migration, update your host configurations to use the new ZFS disko files:

**For desktop:**
```nix
# In /nixos/hosts/desktop/default.nix
{
  imports = [
    ./hardware-configuration.nix
    ./disko-zfs.nix  # Changed from disko.nix
    ../../modules/system/zfs.nix
  ];
}
```

**For server:**
```nix
# In /nixos/hosts/server/default.nix
{
  imports = [
    ./hardware-configuration.nix
    ./disko-zfs.nix  # Changed from disko.nix
    ../../modules/system/zfs.nix
  ];
}
```

### 5. Verify ZFS Setup

After rebooting into the new system:

```bash
# Check ZFS pool status
zpool status

# Check available datasets
zfs list

# Test snapshot creation
zfs snapshot rpool/root@test-snapshot
zfs list -t snapshot

# Test rollback (if needed)
zfs rollback rpool/root@test-snapshot
```

## ZFS Workflow Integration

### Daily Workflow

```bash
# Before making system changes
zfs snapshot rpool/root@pre-update-$(date +%Y%m%d-%H%M%S)

# Make your changes
git pull
home-manager switch
nixos-rebuild switch

# If issues occur, rollback
zfs rollback rpool/root@pre-update-YYYYMMDD-HHMMSS
```

### Maintenance Commands

```bash
# Manual scrub (data integrity check)
zpool scrub rpool

# Check scrub status
zpool status -v

# List all snapshots
zfs list -t snapshot

# Remove old snapshots
zfs destroy rpool/root@old-snapshot

# Check ZFS performance statistics
zpool iostat -v 1
```

## ZFS Dataset Structure

Your new ZFS structure:

```
rpool (root pool)
├── root          (/) - System root with auto-snapshots
├── nix           (/nix) - Nix store (no snapshots)
├── home          (/home) - User directories
├── persist       (/persist) - Persistent data
│   ├── system    (/persist/system) - System state
│   └── home      (/persist/home) - User persistent data
```

## Auto-Snapshot Configuration

The system is configured to automatically create snapshots:

- **Frequent**: Every 15 minutes, keep 4 snapshots (1 hour)
- **Hourly**: Keep 24 snapshots (1 day)
- **Daily**: Keep 7 snapshots (1 week)
- **Weekly**: Keep 4 snapshots (1 month)
- **Monthly**: Keep 12 snapshots (1 year)

## Performance Tuning

The configuration includes:

- **ARC Cache**: 1GB minimum, 4GB maximum
- **Compression**: LZ4 for good balance of speed and ratio
- **TRIM**: Enabled for SSD optimization
- **Auto-scrub**: Monthly data integrity checks

## Troubleshooting

### Common Issues

1. **Boot failure**: Ensure GRUB is properly installed with ZFS support
2. **Pool import failure**: Use `zpool import -f rpool` to force import
3. **Memory issues**: Adjust ARC size if system has limited RAM

### Recovery Commands

```bash
# Import pool if not mounted
zpool import -R /mnt rpool

# Check pool health
zpool status -x

# Repair damaged files
zpool scrub rpool
zpool status -v  # Check for errors
```

## Hetzner VPS Setup

For Hetzner servers:

1. Use their rescue system
2. Install NixOS with ZFS support enabled
3. Upload your configuration
4. Run the migration script with appropriate disk device
5. Configure networking for Hetzner's infrastructure

The ZFS configuration is compatible with Hetzner's dedicated servers and most VPS offerings.