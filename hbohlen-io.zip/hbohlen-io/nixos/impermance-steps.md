# Impermanence Setup with ZFS Migration

This guide provides step-by-step commands to set up NixOS with ZFS and impermanence from a live ISO.

## Prerequisites

- NixOS minimal ISO booted
- Internet connection available
- Target disk identified (e.g., `/dev/sda`, `/dev/nvme0n1`)

## Step-by-Step Commands

### 1. Boot into Live ISO and Setup Network

```bash
# Check network connectivity
ping google.com

# If no internet, setup WiFi (replace with your WiFi details)
nmcli dev wifi list
nmcli dev wifi connect "YourWiFiName" password "YourPassword"

# Verify internet connection
ping google.com
```

### 2. Install Required Tools

```bash
# Install git and other necessary tools
nix-shell -p git curl wget

# Install disko for ZFS partitioning
nix-shell -p disko
```

### 3. Clone Your Configuration

```bash
# Navigate to temp directory
cd /tmp

# Clone your repository
git clone https://github.com/hbohlen/hbohlen-io.git

# Navigate to the nixos directory
cd hbohlen-io/nixos
```

### 4. Identify Target Disk

```bash
# List available disks
lsblk

# Identify your target disk (IMPORTANT: Choose carefully!)
# Common options:
# - /dev/sda (for SATA/USB drives)
# - /dev/nvme0n1 (for NVMe SSDs)
# - /dev/vda (for virtual machines)

# Set your target disk variable (replace with actual disk)
TARGET_DISK="/dev/sda"
echo "Target disk: $TARGET_DISK"
```

### 5. Update Disko Configuration for ZFS

```bash
# Update the ZFS disko configuration with your target disk
# For desktop:
sed -i "s|/dev/sda|$TARGET_DISK|g" hosts/desktop/disko-zfs.nix

# For server:
sed -i "s|/dev/sda|$TARGET_DISK|g" hosts/server/disko-zfs.nix

# Verify the changes
grep -n "device.*=" hosts/desktop/disko-zfs.nix
grep -n "device.*=" hosts/server/disko-zfs.nix

# IMPORTANT: This uses disko-zfs.nix (ZFS), NOT disko.nix (BTRFS)
```

### 6. Apply Disko Configuration (ZFS)

```bash
# Apply the ZFS disko configuration (this will partition and format the disk)
# Choose the appropriate host configuration:

# For desktop:
nix --experimental-features 'nix-command flakes' run github:nix-community/disko -- --mode disko --flake .#desktop

# For server:
nix --experimental-features 'nix-command flakes' run github:nix-community/disko -- --mode disko --flake .#server

# For laptop (if you have a laptop disko config):
# nix --experimental-features 'nix-command flakes' run github:nix-community/disko -- --mode disko --flake .#laptop

# Note: This uses the new disko-zfs.nix configuration files, NOT the old BTRFS disko.nix
```

### 7. Mount Filesystems

```bash
# Mount the root filesystem
mount /dev/disk/by-label/nixos /mnt

# Create necessary directories
mkdir -p /mnt/boot
mkdir -p /mnt/nix
mkdir -p /mnt/home
mkdir -p /mnt/persist

# Mount boot partition (EFI)
mount /dev/disk/by-label/ESP /mnt/boot

# Mount ZFS datasets (if using ZFS)
# The disko configuration should have already mounted them, but verify:
mount | grep zfs
```

### 8. Generate NixOS Configuration

```bash
# Generate basic hardware configuration
nixos-generate-config --root /mnt

# The configuration will be generated at /mnt/etc/nixos/configuration.nix
# We'll replace it with our own configuration
```

### 9. Copy Your Configuration

```bash
# Copy your configuration to the target system
cp -r /tmp/hbohlen-io/nixos/* /mnt/etc/nixos/

# Navigate to the configuration directory
cd /mnt/etc/nixos
```

### 10. Install NixOS

```bash
# Install NixOS with your configuration
nixos-install --root /mnt --flake .#desktop

# Or for server:
# nixos-install --root /mnt --flake .#server

# Or for laptop:
# nixos-install --root /mnt --flake .#laptop
```

### 11. Set Root Password

```bash
# Set root password for the new system
nixos-enter --root /mnt
passwd root
exit
```

### 12. Verify Installation

```bash
# Check that all filesystems are mounted properly
mount | grep -E "(zfs|ext4|vfat)"

# Check ZFS pool status (if using ZFS)
zpool status

# Check available space
df -h
```

### 13. Reboot

```bash
# Unmount all filesystems
umount -R /mnt

# Export ZFS pool (if using ZFS)
zpool export rpool

# Reboot the system
reboot
```

## Post-Installation Steps

### 14. First Boot Configuration

```bash
# After reboot, login as root and set up your user
# Your user should already be created, but set password:
passwd hbohlen

# Verify user groups
groups hbohlen

# Check that all services are running
systemctl status
```

### 15. Test Impermanence

```bash
# Test that persistent directories are working
ls -la /persist/system/
ls -la /persist/home/hbohlen/

# Create a test file in persistent directory
echo "test" > /persist/system/test-file
reboot

# After reboot, verify the test file exists
cat /persist/system/test-file
```

### 16. Test ZFS Snapshots

```bash
# Create a test snapshot
zfs snapshot rpool/root@test-snapshot

# List snapshots
zfs list -t snapshot

# Test rollback (optional)
# zfs rollback rpool/root@test-snapshot
```

### 17. Verify Git Workflow

```bash
# Navigate to your configuration directory
cd /etc/nixos

# Pull latest changes
git pull

# Test system rebuild
nixos-rebuild switch --flake .#desktop

# Test home-manager
home-manager switch --flake .#hbohlen@desktop
```

## Troubleshooting

### Common Issues

1. **Disk not found**: Double-check the `TARGET_DISK` variable
2. **Permission denied**: Ensure you're running as root
3. **Network issues**: Verify WiFi/Ethernet connection
4. **ZFS import issues**: Use `zpool import -f rpool` to force import

### Recovery Commands

```bash
# If system fails to boot, boot from live ISO and:
mount /dev/disk/by-label/nixos /mnt
nixos-enter --root /mnt

# Inside the chroot, you can:
# - Fix configuration issues
# - Rebuild system: nixos-rebuild switch
# - Reset bootloader: nixos-rebuild boot
```

## Important Notes

- **BACKUP YOUR DATA**: This process will erase all data on the target disk
- **CHOOSE DISK CAREFULLY**: Using the wrong disk will result in data loss
- **VERIFY EACH STEP**: Don't proceed until each step completes successfully
- **DOCUMENTATION**: Keep this guide handy during the setup process

## Configuration Files to Review

Before running the installation, review these files:

- `hosts/[hostname]/disko-zfs.nix` - ZFS disk partitioning scheme (NEW)
- `hosts/[hostname]/default.nix` - Host-specific configuration (updated for ZFS)
- `modules/system/common.nix` - Common system settings (updated for GRUB+ZFS)
- `modules/system/zfs.nix` - ZFS-specific settings (NEW)

Make sure all paths and device names match your actual hardware configuration.

## Important: ZFS vs BTRFS

- **OLD**: `disko.nix` - BTRFS configuration (do not use for ZFS migration)
- **NEW**: `disko-zfs.nix` - ZFS configuration (use this for ZFS migration)

The migrate-to-zfs.sh script is an alternative manual approach, but using disko-zfs.nix is recommended for better Nix integration.